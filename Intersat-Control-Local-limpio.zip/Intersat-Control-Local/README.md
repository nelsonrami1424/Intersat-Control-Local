# Intersat Control

Sistema web de control de asistencia de Intersat Los Andes.

## Estructura
- `index.html`: interfaz principal.
- `css/`: estilos.
- `js/`: lógica de asistencia, autenticación y respaldos.
- `images/`: recursos gráficos.
- `bridge/`: conector local para comprobar comunicación con dispositivos Hikvision mediante ISAPI.

## Abrir la aplicación
Abre `index.html` en un navegador compatible.

## Conector local Hikvision
Consulta `bridge/LEEME.txt` para los requisitos e instrucciones. El conector actual permite comprobar el servicio local y consultar información básica del dispositivo. **Esta versión todavía no recibe ni registra automáticamente las marcaciones biométricas.**

Requisitos del conector: Windows 10/11 y Python 3.10 o superior. Las dependencias están en `bridge/requirements.txt`; no se incluye el entorno virtual (`.venv`) porque debe instalarse localmente.

## Importante
- No subas contraseñas, datos personales de trabajadores ni datos biométricos.
- El proyecto usa almacenamiento local del navegador en esta etapa; publicar el código en GitHub no convierte los datos en una base de datos compartida ni despliega la aplicación en un servidor.
